(function () {
    let alphaToken = 'QZRNOExQT4ezbWi9iyxLBAZ6VFlAnKm3QhWc12l3LKXjq4cIsBaqOFZ9yBlhTy2m';
    const experiment1 = false;
    const debug = true;

    const shadowContainer = document.createElement('div');
    document.body.appendChild(shadowContainer);

    const shadowRoot = shadowContainer.attachShadow({ mode: 'open' });

    fetch(chrome.runtime.getURL('styles.css'))
        .then(response => response.text())
        .then(css => {
            const styleElement = document.createElement('style');
            styleElement.textContent = css;
            shadowRoot.appendChild(styleElement);
            initExtension();
        });

    function initExtension() {
        let MotherBoxHTML = `
            <div id="mother_box"></div>
        `;

        function CreateAskBox(id) {
            let AskBoxHTML = `
            <div class="ask_box_1" id="ask_box_1_id_${id}">
                <textarea class="ask_box_1_textarea_1" placeholder="Ask Cosmo" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"></textarea>
                <div style="display: flex; padding: 8px; align-items: center;">
                    <div class="ask_box_1_button_1 magnetic_hover_1 no_select" tabindex="0">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="#FFF">
                            <path d="M9 17.25C4.47656 17.25 0.75 13.5252 0.75 8.99609C0.75 4.4748 4.46875 0.75 9 0.75C13.5235 0.75 17.25 4.4748 17.25 8.99609C17.25 13.5252 13.5313 17.25 9 17.25ZM9.00781 13.2285C9.53906 13.2285 9.94531 12.8615 9.94531 12.346V8.87896L9.84375 7.25473L10.4532 8.09026L11.2735 8.98828C11.4141 9.16008 11.6407 9.25378 11.875 9.25378C12.3516 9.25378 12.6875 8.92581 12.6875 8.4729C12.6875 8.22302 12.6172 8.04342 12.4375 7.8482L9.77344 5.07607C9.55468 4.8418 9.3125 4.73249 9.00781 4.73249C8.70312 4.73249 8.46875 4.8418 8.25 5.07607L5.57812 7.8482C5.39844 8.04342 5.32812 8.22302 5.32812 8.4729C5.32812 8.92581 5.66406 9.25378 6.14062 9.25378C6.375 9.25378 6.60156 9.15226 6.74218 8.98828L7.57031 8.06684L8.16406 7.26254L8.07031 8.87896V12.346C8.07031 12.8615 8.47656 13.2285 9.00781 13.2285Z"></path>
                        </svg>
                    </div>
                </div>
            </div>
            `;
            const motherBoxCloseButtonHouse = shadowRoot.querySelector("#mother_box_close_button_house_1");

            if (motherBoxCloseButtonHouse) {
                motherBoxElement.insertBefore(
                    document.createRange().createContextualFragment(AskBoxHTML),
                    motherBoxCloseButtonHouse
                );
            } else {
                motherBoxElement.insertAdjacentHTML('beforeend', AskBoxHTML);
            }

            const AskBox = shadowRoot.querySelector(`#ask_box_1_id_${id}`);
            const AskBoxInput = shadowRoot.querySelector(`#ask_box_1_id_${id} .ask_box_1_textarea_1`);
            const AskBoxButton = shadowRoot.querySelector(`#ask_box_1_id_${id} .ask_box_1_button_1`);

            AskBoxButton.style.pointerEvents = "none";
            AskBoxButton.style.opacity = "0.5";

            magnetize(AskBoxButton);

            if (AskBoxInput) AskBoxInput.focus();

            AskBoxButton.addEventListener("click", function () {
                handleQuery(id);
            });

            AskBoxInput.addEventListener('input', (event) => {
                if (AskBoxInput.value.trim()) {
                    if (AskBoxButton.style.pointerEvents === "none") {
                        AskBoxButton.style.pointerEvents = "all";
                        AskBoxButton.style.opacity = "";
                    }
                } else {
                    if (AskBoxButton.style.pointerEvents !== "none") {
                        AskBoxButton.style.pointerEvents = "none";
                        AskBoxButton.style.opacity = "0.5";
                    }
                }
            });

            AskBoxInput.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' && !event.shiftKey) {
                    if (AskBoxInput.value.trim()) {
                        AskBoxButton.style.transform = "scale(0.8)";
                        AskBoxButton.style.filter = "brightness(0.8)";
                        event.preventDefault();
                        event.stopPropagation();
                    }
                }

                if (event.key === 'Backspace') {
                    event.stopPropagation();
                }

                event.stopPropagation();
            }, true);

            AskBoxInput.addEventListener('keyup', function (event) {
                if (event.key === 'Enter' && !event.shiftKey) {
                    if (AskBoxInput.value.trim()) {
                        AskBoxButton.style.transform = "";
                        AskBoxButton.style.filter = "";
                        handleQuery(id);

                        AskBoxButton.remove();

                        const paragraph = document.createElement("p");
                        paragraph.classList.add("ask_box_1_text_1");
                        paragraph.classList.add("text_select");
                        paragraph.textContent = AskBoxInput.value;
                        paragraph.style.width = "100%";
                        AskBoxInput.replaceWith(paragraph);
                    }
                }

                event.stopPropagation();
            }, true);

            AskBoxInput.addEventListener('focus', function (event) {
                event.stopPropagation();
            }, true);
        }

        function CreateIntelligenceBox(id) {
            let IntelligenceBoxHTML = `
            <div class="intelligence_box_1" id="intelligence_box_1_id_${id}">
                <p class="intelligence_box_1_text_1 text_select" style="width: 100%; opacity: 0; filter: blur(4px); transition: 0.8s cubic-bezier(0.16, 1, 0.32, 1);"></p>
            </div>
            `;
            const motherBoxCloseButtonHouse = shadowRoot.querySelector("#mother_box_close_button_house_1");

            if (motherBoxCloseButtonHouse) {
                motherBoxElement.insertBefore(
                    document.createRange().createContextualFragment(IntelligenceBoxHTML),
                    motherBoxCloseButtonHouse
                );
            } else {
                motherBoxElement.insertAdjacentHTML('beforeend', IntelligenceBoxHTML);
            }
        }

        let CloseComponent1HTML = `
        <div id="mother_box_close_button_house_1" style="display: flex; padding: 0px 8px; align-items: flex-start; gap: 8px;">
            <div id="delete_button_1" class="close_button_1 magnetic_hover_1 no_select" tabindex="0">
                <svg width="17" height="19" viewBox="0 0 17 19" fill="var(--text)" xmlns="http://www.w3.org/2000/svg">
                    <path opacity="0.5" d="M5.03906 18.1094C3.69531 18.1094 2.88281 17.375 2.82031 16.0312L2.30469 4.95312H1.57031C1.07812 4.95312 0.695312 4.59375 0.695312 4.09375C0.695312 3.60156 1.07812 3.24219 1.57031 3.24219H4.88281V2.10938C4.88281 0.804688 5.69531 0.0703125 7.14844 0.0703125H10.125C11.5781 0.0703125 12.3984 0.804688 12.3984 2.10938V3.24219H15.7109C16.2109 3.24219 16.5938 3.60156 16.5938 4.09375C16.5938 4.59375 16.2188 4.95312 15.7109 4.95312H14.9844L14.4688 16.0312C14.4062 17.3672 13.5859 18.1094 12.25 18.1094H5.03906ZM6.67969 2.17188V3.24219H10.6016V2.17188C10.6016 1.83594 10.3672 1.63281 9.99219 1.63281H7.28125C6.91406 1.63281 6.67969 1.83594 6.67969 2.17188ZM6.22656 15.6016C6.63281 15.6016 6.89844 15.3438 6.88281 14.9531L6.64062 6.64844C6.625 6.25781 6.35938 6.00781 5.96875 6.00781C5.5625 6.00781 5.30469 6.26562 5.3125 6.65625L5.55469 14.9609C5.57812 15.3516 5.83594 15.6016 6.22656 15.6016ZM8.64062 15.6016C9.03906 15.6016 9.30469 15.3516 9.30469 14.9688V6.64844C9.30469 6.25781 9.03906 6.00781 8.64062 6.00781C8.25 6.00781 7.98438 6.25781 7.98438 6.64844V14.9688C7.98438 15.3516 8.25 15.6016 8.64062 15.6016ZM11.0625 15.6016C11.4531 15.6016 11.7109 15.3516 11.7266 14.9609L11.9688 6.65625C11.9844 6.26562 11.7266 6.00781 11.3203 6.00781C10.9297 6.00781 10.6641 6.25781 10.6484 6.64844L10.3984 14.9531C10.3906 15.3438 10.6484 15.6016 11.0625 15.6016Z"/>
                </svg>
            </div>
            <div id="close_button_1" class="delete_button_1 magnetic_hover_1 no_select" tabindex="0">
                <svg width="17" height="18" viewBox="0 0 17 18" fill="var(--text)" xmlns="http://www.w3.org/2000/svg">
                    <path opacity="0.5" d="M8.64844 17.1094C4.09375 17.1094 0.398438 13.4141 0.398438 8.85938C0.398438 4.30469 4.09375 0.609375 8.64844 0.609375C13.2031 0.609375 16.8984 4.30469 16.8984 8.85938C16.8984 13.4141 13.2031 17.1094 8.64844 17.1094ZM6.1875 12.2188C6.46094 12.2188 6.67969 12.125 6.85156 11.9531L8.64844 10.1484L10.4531 11.9531C10.625 12.125 10.8516 12.2188 11.1172 12.2188C11.625 12.2188 12.0156 11.8203 12.0156 11.3125C12.0156 11.0781 11.9219 10.8594 11.7422 10.6875L9.92969 8.875L11.75 7.04688C11.9297 6.875 12.0156 6.65625 12.0156 6.42188C12.0156 5.92188 11.625 5.53125 11.125 5.53125C10.8594 5.53125 10.6562 5.60938 10.4688 5.79688L8.64844 7.60156L6.84375 5.79688C6.66406 5.625 6.46094 5.53906 6.1875 5.53906C5.6875 5.53906 5.29688 5.92188 5.29688 6.4375C5.29688 6.66406 5.39062 6.88281 5.5625 7.05469L7.38281 8.875L5.5625 10.6953C5.39062 10.8594 5.29688 11.0859 5.29688 11.3125C5.29688 11.8203 5.6875 12.2188 6.1875 12.2188Z" />
                </svg>
            </div>
        </div>
        `;

        const motherBoxContainer = document.createElement('div');
        motherBoxContainer.innerHTML = MotherBoxHTML;
        shadowRoot.appendChild(motherBoxContainer);

        const motherBoxElement = motherBoxContainer.querySelector("#mother_box");

        CreateAskBox(1);
        motherBoxElement.insertAdjacentHTML('beforeend', CloseComponent1HTML);

        const closeButton = shadowRoot.getElementById("close_button_1");
        const deleteButton = shadowRoot.getElementById("delete_button_1");
        magnetize(closeButton);
        magnetize(deleteButton);

        let currentChatID = 1;

        function magnetize(element) {
            let mouseDown = false;
            let originalZIndex = null;
            element.addEventListener("mousemove", (e) => {
                const rect = element.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                if (mouseDown) {
                    element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(0.9)`;
                } else {
                    element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(1.1)`;
                }
                if (!originalZIndex) {
                    if (element.style.zIndex) originalZIndex = parseInt(element.style.zIndex);
                    else originalZIndex = 0;
                }
                element.style.zIndex = originalZIndex + 1;
            });
            element.addEventListener("mouseleave", () => {
                element.style.transform = "translate(0, 0) scale(1)";
                element.style.zIndex = originalZIndex;
                mouseDown = false;
            });
            element.addEventListener("mousedown", (e) => {
                mouseDown = true;
                const rect = element.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                if (mouseDown) {
                    element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(0.9)`;
                } else {
                    element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(1.1)`;
                }
            });
            element.addEventListener("mouseup", (e) => {
                mouseDown = false;
                const rect = element.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                if (mouseDown) {
                    element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(0.9)`;
                } else {
                    element.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px) scale(1.1)`;
                }
            });
        }

        let magnetic_hover_1 = shadowRoot.querySelectorAll(".magnetic_hover_1");
        magnetic_hover_1.forEach((element) => {
            magnetize(element);
        });

        function blurFadeTransformText(element, text, totalDuration = 1000) {
            element.innerHTML = "";
            const parts = text.split(/(\s+)/);
            const totalChars = text.replace(/\s+/g, "").length;
            const characterDelay = totalDuration / totalChars;
            let currentDelay = 0;

            parts.forEach((part) => {
                if (/\s+/.test(part)) {
                    element.appendChild(document.createTextNode(part));
                } else {
                    const wordSpan = document.createElement("span");
                    wordSpan.style.whiteSpace = "nowrap";
                    [...part].forEach((char) => {
                        const span = document.createElement("span");
                        span.textContent = char;
                        span.className = "char-span";
                        span.style.opacity = "0";
                        span.style.filter = "blur(4px)";
                        wordSpan.appendChild(span);

                        setTimeout(() => {
                            span.style.opacity = "1";
                            span.style.filter = "blur(1px)";
                        }, currentDelay);

                        currentDelay += characterDelay;
                    });
                    element.appendChild(wordSpan);
                }
            });
        }

        function transformText(element, fullText, duration) {
            element.innerText = "";
            const textLength = fullText.length;
            const interval = duration / textLength;
            let currentIndex = 0;
            const startTime = Date.now();

            function updateText() {
                const now = Date.now();
                const elapsed = now - startTime;
                const expectedIndex = Math.floor(elapsed / interval);

                while (currentIndex <= expectedIndex && currentIndex < textLength) {
                    element.textContent += fullText[currentIndex];
                    currentIndex++;
                }

                if (currentIndex >= textLength) return;
                const nextCall = startTime + (currentIndex * interval) - now;
                setTimeout(updateText, nextCall);
            }

            updateText();
        }

        let conversationHistory = [];

        function getVisibleText() {
            const walker = document.createTreeWalker(
                document.body,
                NodeFilter.SHOW_TEXT,
                {
                    acceptNode: function (node) {
                        const text = node.nodeValue.trim();
                        if (!text) return NodeFilter.FILTER_REJECT;

                        const parent = node.parentElement;
                        if (!parent) return NodeFilter.FILTER_REJECT;

                        const excludedTags = ['style', 'script', 'noscript', 'template', 'iframe', 'canvas', 'code', 'pre'];
                        if (excludedTags.includes(parent.tagName.toLowerCase())) {
                            return NodeFilter.FILTER_REJECT;
                        }

                        const ariaHidden = parent.getAttribute('aria-hidden');
                        if (ariaHidden && ariaHidden.toLowerCase() === 'true') {
                            return NodeFilter.FILTER_REJECT;
                        }

                        let el = parent;
                        while (el && el !== document.documentElement) {
                            const style = window.getComputedStyle(el);
                            if (
                                style.display === 'none' ||
                                style.visibility === 'hidden' ||
                                parseFloat(style.opacity) === 0
                            ) {
                                return NodeFilter.FILTER_REJECT;
                            }
                            el = el.parentElement;
                        }

                        return NodeFilter.FILTER_ACCEPT;
                    }
                },
                false
            );

            let extractedText = '';
            let currentNode;
            let lastParent = null;

            while (currentNode = walker.nextNode()) {
                const parent = currentNode.parentElement;

                if (lastParent && parent !== lastParent) {
                    extractedText += '\n';
                }

                extractedText += currentNode.nodeValue.trim() + ' ';

                lastParent = parent;
            }

            extractedText = extractedText.trim();
            return extractedText;
        }

        async function fetchAnswer(question) {
            conversationHistory.push({ author: "user", message: question });
            const websiteHTML = getVisibleText();
            if (debug) console.log(websiteHTML);

            try {
                const response = await fetch('https://cosmos.pythonanywhere.com/api/extension/gate/1', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        token: alphaToken,
                        website: {
                            URL: window.location.href,
                            HTML: websiteHTML
                        },
                        chat: conversationHistory,
                        metadata: {
                            time: Date.now(),
                            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                            userAgent: navigator.userAgent,
                            screenSize: {
                                width: window.innerWidth,
                                height: window.innerHeight
                            }
                        }
                    })
                });

                if (response.ok) {
                    const data = await response.json();
                    const answer = data.intelligence.message || "No answer provided.";

                    conversationHistory.push({ author: "assistant", message: answer });

                    return answer;
                } else {
                    console.error('Error fetching answer:', response);
                    return "Failed to get a response.";
                }
            } catch (error) {
                console.error('Fetch error:', error);
                return "Failed to get a response.";
            }
        }

        async function handleQuery(id) {
            if (id != currentChatID) return;

            const inputField = shadowRoot.querySelector("#ask_box_1_id_" + currentChatID + " .ask_box_1_textarea_1");

            const question = inputField.value.trim();
            if (!question) return;

            CreateIntelligenceBox(currentChatID);

            const intelligenceText = shadowRoot.querySelector("#intelligence_box_1_id_" + currentChatID + " .intelligence_box_1_text_1");

            intelligenceText.innerText = "Reading Website";
            intelligenceText.style.opacity = 0;
            intelligenceText.style.filter = "blur(4px)";
            intelligenceText.offsetHeight;
            intelligenceText.style.opacity = 1;
            intelligenceText.style.filter = "blur(0px)";

            const answer = await fetchAnswer(question);

            intelligenceText.offsetHeight;
            intelligenceText.style.opacity = 0;
            intelligenceText.style.filter = "blur(4px)";

            setTimeout(() => {
                intelligenceText.style.transition = "none";
                intelligenceText.innerText = "";

                intelligenceText.offsetHeight;
                intelligenceText.style.opacity = 1;
                intelligenceText.style.filter = "blur(0px)";
                intelligenceText.offsetHeight;

                transformText(intelligenceText, answer, 400);
                setTimeout(() => {
                    currentChatID++;
                    CreateAskBox(currentChatID);
                }, 400);
            }, 800);
        }

        let isVisible = false;
        let isVisibleTransitioning = false;

        function toggleMotherBox() {
            if (isVisibleTransitioning) return;
            isVisible = !isVisible;
            isVisibleTransitioning = true;

            if (isVisible) {
                motherBoxElement.style.display = 'flex';
                if (currentChatID === 1) {
                    function AskboxAnimation1() {
                        const AskBox = shadowRoot.querySelector(`#ask_box_1_id_${currentChatID}`);
                        AskBox.offsetHeight;
                        let AskBoxHeight = parseFloat(AskBox.offsetHeight);
                        AskBox.style.position = "relative";
                        AskBox.style.filter = "blur(16px)";
                        AskBox.style.opacity = "0";
                        AskBox.offsetHeight;
                        AskBox.style.top = ((-AskBoxHeight) - 16) + "px";
                        AskBox.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                        AskBox.offsetHeight;

                        AskBox.style.top = "0px";
                        AskBox.style.filter = "blur(0px)";
                        AskBox.style.opacity = "1";
                    }
                    function CloseButtonAnimation1() {
                        closeButton.offsetHeight;
                        const closeButtonHeight = parseFloat(closeButton.offsetHeight);
                        const closeButtonOffsetTop = closeButton.getBoundingClientRect().top + window.scrollY;
                        const closeButtonTotalHeight = closeButtonHeight + closeButtonOffsetTop;

                        closeButton.style.position = "relative";
                        closeButton.style.filter = "blur(16px)";
                        closeButton.style.opacity = "0";
                        closeButton.offsetHeight;
                        closeButton.style.top = ((-closeButtonTotalHeight) - 16) + "px";
                        closeButton.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                        closeButton.offsetHeight;

                        closeButton.style.top = "0px";
                        closeButton.style.filter = "blur(0px)";
                        closeButton.style.opacity = "1";
                    }
                    AskboxAnimation1();
                    CloseButtonAnimation1();

                } else {
                    for (let i = 1; i <= currentChatID; i++) {
                        const AskBox = shadowRoot.querySelector(`#ask_box_1_id_${i}`);
                        if (AskBox) {
                            AskBox.offsetHeight;
                            const AskBoxHeight = parseFloat(AskBox.offsetHeight);
                            const AskBoxOffsetTop = AskBox.getBoundingClientRect().top + window.scrollY;
                            const totalHeight = AskBoxHeight + AskBoxOffsetTop;

                            AskBox.style.position = "relative";
                            AskBox.style.filter = "blur(16px)";
                            AskBox.style.opacity = "0";
                            AskBox.offsetHeight;
                            AskBox.style.top = ((-totalHeight) - 16) + "px";
                            AskBox.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                            AskBox.offsetHeight;

                            AskBox.style.top = "0px";
                            AskBox.style.filter = "blur(0px)";
                            AskBox.style.opacity = "1";
                        }
                    }

                    for (let i = 1; i < currentChatID; i++) {
                        const IntelligenceBox = shadowRoot.querySelector(`#intelligence_box_1_id_${i}`);
                        if (IntelligenceBox) {
                            IntelligenceBox.offsetHeight;
                            const IntelligenceBoxHeight = parseFloat(IntelligenceBox.offsetHeight);
                            const IntelligenceBoxOffsetTop = IntelligenceBox.getBoundingClientRect().top + window.scrollY;
                            const totalHeight = IntelligenceBoxHeight + IntelligenceBoxOffsetTop;

                            IntelligenceBox.style.position = "relative";
                            IntelligenceBox.style.filter = "blur(16px)";
                            IntelligenceBox.style.opacity = "0";
                            IntelligenceBox.offsetHeight;
                            IntelligenceBox.style.top = ((-totalHeight) - 16) + "px";
                            IntelligenceBox.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                            IntelligenceBox.offsetHeight;

                            IntelligenceBox.style.top = "0px";
                            IntelligenceBox.style.filter = "blur(0px)";
                            IntelligenceBox.style.opacity = "1";
                        }
                    }

                    closeButton.offsetHeight;
                    const closeButtonHeight = parseFloat(closeButton.offsetHeight);
                    const closeButtonOffsetTop = closeButton.getBoundingClientRect().top + window.scrollY;
                    const closeButtonTotalHeight = closeButtonHeight + closeButtonOffsetTop;

                    closeButton.style.position = "relative";
                    closeButton.style.filter = "blur(16px)";
                    closeButton.style.opacity = "0";
                    closeButton.offsetHeight;
                    closeButton.style.top = ((-closeButtonTotalHeight) - 16) + "px";
                    closeButton.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                    closeButton.offsetHeight;

                    closeButton.style.top = "0px";
                    closeButton.style.filter = "blur(0px)";
                    closeButton.style.opacity = "1";
                }
            } else {
                if (currentChatID === 1) {
                    function AskboxAnimation1() {
                        const AskBox = shadowRoot.querySelector(`#ask_box_1_id_${currentChatID}`);
                        AskBox.offsetHeight;
                        let AskBoxHeight = parseFloat(AskBox.offsetHeight);
                        AskBox.style.position = "relative";
                        AskBox.style.filter = "blur(0px)";
                        AskBox.style.opacity = "1";
                        AskBox.offsetHeight;
                        AskBox.style.top = "0px";
                        AskBox.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                        AskBox.offsetHeight;

                        AskBox.style.top = ((-AskBoxHeight) - 16) + "px";
                        AskBox.style.filter = "blur(8px)";
                        AskBox.style.opacity = "0";

                        setTimeout(() => {
                            motherBoxElement.style.display = 'none';
                        }, 800);
                    }
                    function CloseButtonAnimation1() {
                        closeButton.offsetHeight;
                        const closeButtonHeight = parseFloat(closeButton.offsetHeight);
                        const closeButtonOffsetTop = closeButton.getBoundingClientRect().top + window.scrollY;
                        const closeButtonTotalHeight = closeButtonHeight + closeButtonOffsetTop;

                        closeButton.style.position = "relative";
                        closeButton.style.filter = "blur(0px)";
                        closeButton.style.opacity = "1";
                        closeButton.offsetHeight;
                        closeButton.style.top = "0px";
                        closeButton.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                        closeButton.offsetHeight;

                        closeButton.style.top = ((-closeButtonTotalHeight) - 16) + "px";
                        closeButton.style.filter = "blur(8px)";
                        closeButton.style.opacity = "0";

                        setTimeout(() => {
                            motherBoxElement.style.display = 'none';
                        }, 800);
                    }
                    AskboxAnimation1();
                    CloseButtonAnimation1();
                } else {
                    for (let i = 1; i <= currentChatID; i++) {
                        const AskBox = shadowRoot.querySelector(`#ask_box_1_id_${i}`);
                        if (AskBox) {
                            AskBox.offsetHeight;
                            const AskBoxHeight = parseFloat(AskBox.offsetHeight);
                            const AskBoxOffsetTop = AskBox.getBoundingClientRect().top + window.scrollY;
                            const totalHeight = AskBoxHeight + AskBoxOffsetTop;

                            AskBox.style.position = "relative";
                            AskBox.style.filter = "blur(0px)";
                            AskBox.style.opacity = "1";
                            AskBox.offsetHeight;
                            AskBox.style.top = "0px";
                            AskBox.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                            AskBox.offsetHeight;

                            AskBox.style.top = ((-totalHeight) - 16) + "px";
                            AskBox.style.filter = "blur(8px)";
                            AskBox.style.opacity = "0";

                            setTimeout(() => {
                                motherBoxElement.style.display = 'none';
                            }, 800);
                        }
                    }

                    for (let i = 1; i < currentChatID; i++) {
                        const IntelligenceBox = shadowRoot.querySelector(`#intelligence_box_1_id_${i}`);
                        if (IntelligenceBox) {
                            IntelligenceBox.offsetHeight;
                            const IntelligenceBoxHeight = parseFloat(IntelligenceBox.offsetHeight);
                            const IntelligenceBoxOffsetTop = IntelligenceBox.getBoundingClientRect().top + window.scrollY;
                            const totalHeight = IntelligenceBoxHeight + IntelligenceBoxOffsetTop;

                            IntelligenceBox.style.position = "relative";
                            IntelligenceBox.style.filter = "blur(0px)";
                            IntelligenceBox.style.opacity = "1";
                            IntelligenceBox.offsetHeight;
                            IntelligenceBox.style.top = "0px";
                            IntelligenceBox.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                            IntelligenceBox.offsetHeight;

                            IntelligenceBox.style.top = ((-totalHeight) - 16) + "px";
                            IntelligenceBox.style.filter = "blur(8px)";
                            IntelligenceBox.style.opacity = "0";

                            setTimeout(() => {
                                motherBoxElement.style.display = 'none';
                            }, 800);
                        }
                    }

                    closeButton.offsetHeight;
                    const closeButtonHeight = parseFloat(closeButton.offsetHeight);
                    const closeButtonOffsetTop = closeButton.getBoundingClientRect().top + window.scrollY;
                    const closeButtonTotalHeight = closeButtonHeight + closeButtonOffsetTop;

                    closeButton.style.position = "relative";
                    closeButton.style.filter = "blur(0px)";
                    closeButton.style.opacity = "1";
                    closeButton.offsetHeight;
                    closeButton.style.top = "0px";
                    closeButton.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                    closeButton.offsetHeight;

                    closeButton.style.top = ((-closeButtonTotalHeight) - 16) + "px";
                    closeButton.style.filter = "blur(8px)";
                    closeButton.style.opacity = "0";

                    setTimeout(() => {
                        motherBoxElement.style.display = 'none';
                    }, 800);
                }

            }
            setTimeout(() => {
                isVisibleTransitioning = false;
            }, 800);
        }

        function toggleExperiment2() {
            if (isVisibleTransitioning) return;
            isVisibleTransitioning = true;
            const children = Array.from(motherBoxElement.children);

            if (isVisible) {
                motherBoxElement.style.right = "16px";
                motherBoxElement.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";

                children.forEach(child => {
                    child.style.filter = "blur(0px)";
                    child.style.opacity = "1";
                    child.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";
                });

                motherBoxElement.offsetHeight;

                motherBoxElement.style.right = "-384px";
                children.forEach(child => {
                    child.style.filter = "blur(16px)";
                    child.style.opacity = "0";
                });

                setTimeout(() => {
                    motherBoxElement.style.display = 'none';
                }, 800);
            } else {
                motherBoxElement.style.right = "-384px";
                motherBoxElement.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";
                motherBoxElement.style.display = 'flex';

                children.forEach(child => {
                    child.style.filter = "blur(16px)";
                    child.style.opacity = "0";
                    child.style.transition = "0.8s cubic-bezier(0.16, 1, 0.32, 1)";
                });

                motherBoxElement.offsetHeight;

                motherBoxElement.style.right = "16px";
                children.forEach(child => {
                    child.style.filter = "blur(0px)";
                    child.style.opacity = "1";
                });

                const askBoxInput = shadowRoot.querySelector(`#ask_box_1_id_${currentChatID} .ask_box_1_textarea_1`);
                if (askBoxInput) askBoxInput.focus();

                setTimeout(() => {
                    motherBoxElement.style.right = "";
                    children.forEach(child => {
                        child.style.filter = "";
                        child.style.opacity = "";
                    });
                }, 800);
            }

            setTimeout(() => {
                isVisible = !isVisible;
                isVisibleTransitioning = false;
            }, 800);
        }

        let simpleThemeDetect = true;
        function detectTheme() {
            if (simpleThemeDetect) {
                const bodyElement = document.body || document.documentElement;
                const computedStyle = window.getComputedStyle(bodyElement);
                const backgroundColor = computedStyle.backgroundColor;

                const calculateLuminance = (r, g, b) => {
                    const rsRGB = r / 255;
                    const gsRGB = g / 255;
                    const bsRGB = b / 255;

                    const rLinear = rsRGB <= 0.03928 ? rsRGB / 12.92 : Math.pow((rsRGB + 0.055) / 1.055, 2.4);
                    const gLinear = gsRGB <= 0.03928 ? gsRGB / 12.92 : Math.pow((gsRGB + 0.055) / 1.055, 2.4);
                    const bLinear = bsRGB <= 0.03928 ? bsRGB / 12.92 : Math.pow((bsRGB + 0.055) / 1.055, 2.4);

                    return 0.2126 * rLinear + 0.7152 * gLinear + 0.0722 * bLinear;
                };

                let luminance = 0;

                if (backgroundColor.startsWith('rgb')) {
                    const match = backgroundColor.match(/\d+/g);
                    if (match) {
                        const [r, g, b] = match.map(Number);
                        luminance = calculateLuminance(r, g, b);
                    }
                }

                return {
                    isDark: luminance < 0.5,
                    isLight: luminance >= 0.5,
                    luminance: luminance
                };
            } else {
                const elements = document.getElementsByTagName('*');
                let totalLuminance = 0;
                let elementCount = 0;

                const hexToRgb = (hex) => {
                    hex = hex.replace('#', '');

                    if (hex.length === 3) {
                        hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
                    }

                    const r = parseInt(hex.substring(0, 2), 16);
                    const g = parseInt(hex.substring(2, 4), 16);
                    const b = parseInt(hex.substring(4, 6), 16);

                    return [r, g, b];
                };

                const calculateLuminance = (r, g, b) => {
                    const rsRGB = r / 255;
                    const gsRGB = g / 255;
                    const bsRGB = b / 255;

                    const rLinear = rsRGB <= 0.03928 ? rsRGB / 12.92 : Math.pow((rsRGB + 0.055) / 1.055, 2.4);
                    const gLinear = gsRGB <= 0.03928 ? gsRGB / 12.92 : Math.pow((gsRGB + 0.055) / 1.055, 2.4);
                    const bLinear = bsRGB <= 0.03928 ? bsRGB / 12.92 : Math.pow((bsRGB + 0.055) / 1.055, 2.4);

                    return 0.2126 * rLinear + 0.7152 * gLinear + 0.0722 * bLinear;
                };

                for (let element of elements) {
                    const styles = window.getComputedStyle(element);
                    const backgroundColor = styles.backgroundColor;
                    const color = styles.color;

                    if (backgroundColor === 'transparent' || backgroundColor === 'rgba(0, 0, 0, 0)') {
                        continue;
                    }

                    if (backgroundColor.startsWith('rgb')) {
                        const match = backgroundColor.match(/\d+/g);
                        if (match) {
                            const [r, g, b] = match.map(Number);
                            totalLuminance += calculateLuminance(r, g, b);
                            elementCount++;
                        }
                    }
                    else if (backgroundColor.startsWith('#')) {
                        const [r, g, b] = hexToRgb(backgroundColor);
                        totalLuminance += calculateLuminance(r, g, b);
                        elementCount++;
                    }
                }

                const averageLuminance = totalLuminance / elementCount;

                return {
                    isDark: averageLuminance < 0.5,
                    isLight: averageLuminance >= 0.5,
                    luminance: averageLuminance
                };
            }
        }

        let previousTheme = null;

        function monitorTheme() {
            const currentTheme = detectTheme();
            const themeString = currentTheme.isDark ? 'dark' : 'light';

            if (previousTheme === null || previousTheme !== themeString) {
                previousTheme = themeString;
                toggleColorScheme(shadowRoot, themeString);
            }
        }

        function toggleColorScheme(shadowRoot, theme) {
            if (theme === 'light') {
                shadowRoot.host.style.setProperty('--ask-box-background', 'rgba(255, 255, 255, 0.9)');
                shadowRoot.host.style.setProperty('--ask-box-outline', 'rgba(0, 0, 0, 0.1)');
                shadowRoot.host.style.setProperty('--ask-box-text', 'rgba(0, 0, 0, 0.8)');
                shadowRoot.host.style.setProperty('--intelligence-box-background', 'rgba(255, 255, 255, 0.9)');
                shadowRoot.host.style.setProperty('--intelligence-box-outline', 'rgba(0, 0, 0, 0.1)');
                shadowRoot.host.style.setProperty('--close-button-background', 'rgba(255, 255, 255, 0.9)');
                shadowRoot.host.style.setProperty('--close-button-outline', 'rgba(0, 0, 0, 0.1)');
                shadowRoot.host.style.setProperty('--text', 'rgba(0, 0, 0, 1)');
                shadowRoot.host.style.setProperty('--red', '#ff3b30');
                shadowRoot.host.style.setProperty('--orange', '#ff9500');
                shadowRoot.host.style.setProperty('--yellow', '#ffcc00');
                shadowRoot.host.style.setProperty('--green', '#34c759');
                shadowRoot.host.style.setProperty('--teal', '#00c7be');
                shadowRoot.host.style.setProperty('--cyan', '#5ac8fa');
                shadowRoot.host.style.setProperty('--blue', '#007aff');
                shadowRoot.host.style.setProperty('--indigo', '#5856d6');
                shadowRoot.host.style.setProperty('--purple', '#af52de');
                shadowRoot.host.style.setProperty('--pink', '#ff2d55');
            } else {
                shadowRoot.host.style.setProperty('--ask-box-background', 'rgba(0, 0, 0, 0.8)');
                shadowRoot.host.style.setProperty('--ask-box-outline', 'rgba(255, 255, 255, 0.2)');
                shadowRoot.host.style.setProperty('--ask-box-text', 'rgba(255, 255, 255, 1)');
                shadowRoot.host.style.setProperty('--intelligence-box-background', 'rgba(0, 0, 0, 0.9)');
                shadowRoot.host.style.setProperty('--intelligence-box-outline', 'rgba(255, 255, 255, 0.2)');
                shadowRoot.host.style.setProperty('--close-button-background', 'rgba(0, 0, 0, 0.9)');
                shadowRoot.host.style.setProperty('--close-button-outline', 'rgba(255, 255, 255, 0.2)');
                shadowRoot.host.style.setProperty('--text', 'rgba(255, 255, 255, 1)');
                shadowRoot.host.style.setProperty('--red', '#ff453a');
                shadowRoot.host.style.setProperty('--orange', '#ff9f0a');
                shadowRoot.host.style.setProperty('--yellow', '#ffd60a');
                shadowRoot.host.style.setProperty('--green', '#30d158');
                shadowRoot.host.style.setProperty('--teal', '#63e6e2');
                shadowRoot.host.style.setProperty('--cyan', '#64d2ff');
                shadowRoot.host.style.setProperty('--blue', '#0a84ff');
                shadowRoot.host.style.setProperty('--indigo', '#5e5ce6');
                shadowRoot.host.style.setProperty('--purple', '#bf5af2');
                shadowRoot.host.style.setProperty('--pink', '#ff375f');
            }
        }        

        monitorTheme();
        const themeMonitor = setInterval(monitorTheme, 500);
        // clearInterval(themeMonitor);

        deleteButton.addEventListener("click", () => {
            if (!isVisibleTransitioning) {
                if (experiment1) toggleMotherBox();
                else toggleExperiment2();
                setTimeout(() => {
                    conversationHistory = [];
                    const children = Array.from(motherBoxElement.children);
                    children.forEach(child => {
                        if (!child.id || child.id !== "mother_box_close_button_house_1") {
                            motherBoxElement.removeChild(child);
                        }
                    });
                    currentChatID = 1;
                    CreateAskBox(1);
                }, 800);
            }
        });

        closeButton.addEventListener("click", () => {
            if (experiment1) {
                if (!isVisibleTransitioning) toggleMotherBox();
            } else {
                if (!isVisibleTransitioning) toggleExperiment2();
            }
        });

        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === "toggleMotherBox") {
                if (experiment1) {
                    if (!isVisibleTransitioning) toggleMotherBox();
                } else {
                    if (!isVisibleTransitioning) toggleExperiment2();
                }
            }
        });
    }

})();
